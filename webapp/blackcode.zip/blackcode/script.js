const countdownElement = document.getElementById('countdown');
if (countdownElement) {
  const eventDate = new Date("2025-09-06T00:00:00").getTime();
  function updateCountdown() {
    const now = new Date().getTime();
    const timeLeft = eventDate - now;

    if (timeLeft <= 0) {
      countdownElement.innerHTML = "C'est le jour J !";
      clearInterval(interval);
    } else {
      const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
      countdownElement.innerHTML = `${days}j ${hours}h ${minutes}m ${seconds}s`;
    }
  }
  const interval = setInterval(updateCountdown, 1000);
}
